# Thuto Education login theme

Keycloak login theme for the Thuto Education realm (Keycloakify 11): a campus photo behind the
sign-in card, "Thuto Education" as the title above it, white input fields, and blue and black accents.

Everything is preconfigured: the realm, its clients and the seeded accounts (with their passwords)
are imported on first start, so there is nothing to create before signing in.

## What's in here

- `src/login/Template.tsx` – page layout (top bar, "Thuto Education" title, sign-in card, footer)
- `src/login/main.css` – styling: white inputs with black borders, blue (#1d4ed8) accents, black text and secondary buttons
- `src/login/assets/thuto-hero.jpg` – background photo (the University of South Africa campus)
- `src/login/i18n.ts` – page text
- `vite.config.ts` – theme name (`thuto`) and its run-time setting (`THUTO_HOME_URL`)
- `Dockerfile` – compiles the theme and runs Keycloak 26.8.2 with it on port 4200
- `docker/realm-thuto.json` – the portal's `Thuto Education` realm (same as `keycloak/realm-thuto.json`
  in the portal repo): roles `Admin` / `Student`, clients `thuto-ui` / `thuto-ui-tests`, the seeded
  accounts, and login theme `thuto`

## Run it in Docker on port 4200

Run each command from this folder. Port 4200 must be free (stop the portal container or any
`ng serve` first).

1. Build the image (compiles the theme, then installs it into Keycloak 26.8.2):

   ```bash
   docker build -t thuto-theme .
   ```

2. Run it on port 4200:

   ```bash
   docker run -d --name thuto-theme -p 4200:4200 thuto-theme
   ```

3. Wait until `docker ps` shows the container as `(healthy)` (about 30 seconds), then open the
   Thuto Education sign-in page: <http://localhost:4200/realms/Thuto%20Education/account>

4. Sign in with any of the seeded accounts (Admin or Student). Their usernames and passwords are
   listed under **Dev accounts** in the portal's `thuto-ui/README.md`.

5. Admin console: <http://localhost:4200/admin>, user `admin`, password `admin`. Its own sign-in
   page uses Keycloak's default look: only the `Thuto Education` realm uses the Thuto theme.

6. When you're done, remove it to free port 4200:

   ```bash
   docker rm -f thuto-theme
   ```

The `admin` / `admin` login is for local previews only. To run this anywhere other people can
reach, set your own with `-e KC_BOOTSTRAP_ADMIN_PASSWORD=...` in step 2.

## Change the theme

Edit the files in `src/login/` (to change the photo, save a new one over
`src/login/assets/thuto-hero.jpg`), then rebuild and rerun:

```bash
docker rm -f thuto-theme
docker build -t thuto-theme .
docker run -d --name thuto-theme -p 4200:4200 thuto-theme
```

## Build only the theme jar

Needs Node 20+, Maven and a JDK 17:

```bash
npm ci
npm run build-keycloak-theme
```

The jar is written to `dist_keycloak/thuto-keycloak-theme.jar`. Install it on any Keycloak 26 server
(for example `https://secure.omangwaio.co.za`) by copying it into `/opt/keycloak/providers/`,
restarting Keycloak, and choosing **thuto** under Realm settings → Themes → Login theme for the
`Thuto Education` realm.

## Settings

| Variable                      | Default                  | Used for                                         |
| ----------------------------- | ------------------------ | ------------------------------------------------ |
| `THUTO_HOME_URL`              | `http://localhost:4200/` | "Thuto Education" title and "Back to home" link  |
| `KC_BOOTSTRAP_ADMIN_USERNAME` | `admin`                  | admin console login (local preview)              |
| `KC_BOOTSTRAP_ADMIN_PASSWORD` | `admin`                  | admin console login (local preview)              |
