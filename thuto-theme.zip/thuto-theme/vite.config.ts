import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { keycloakify } from "keycloakify/vite-plugin";

export default defineConfig({
    plugins: [
        react(),
        keycloakify({
            themeName: "thuto",
            accountThemeImplementation: "none",
            // Keycloak 26 only needs the one jar (dist_keycloak/thuto-keycloak-theme.jar).
            keycloakVersionTargets: {
                "22-to-25": false,
                "all-other-versions": "thuto-keycloak-theme.jar"
            },
            // Read at run time from the Keycloak container's environment (see Dockerfile).
            environmentVariables: [{ name: "THUTO_HOME_URL", default: "http://localhost:4200/" }]
        })
    ]
});
