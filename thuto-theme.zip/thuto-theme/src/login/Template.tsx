import { useEffect } from "react";
import { clsx } from "keycloakify/tools/clsx";
import { kcSanitize } from "keycloakify/lib/kcSanitize";
import type { TemplateProps } from "keycloakify/login/TemplateProps";
import { getKcClsx } from "keycloakify/login/lib/kcClsx";
import { useSetClassName } from "keycloakify/tools/useSetClassName";
import { useInitialize } from "keycloakify/login/Template.useInitialize";
import type { I18n } from "./i18n";
import type { KcContext } from "./KcContext";

/** The title shown in the top bar, above the sign-in card and in the footer (whatever the realm's display name). */
const REALM_TITLE = "Thuto Education";

/**
 * Page chrome for every login page: a top bar with the realm name, the "Thuto Education" title above
 * one centred card, and a footer. Mirrors keycloakify/login/Template (same props and behaviour).
 */
export default function Template(props: TemplateProps<KcContext, I18n>) {
    const {
        displayInfo = false,
        displayMessage = true,
        displayRequiredFields = false,
        headerNode,
        socialProvidersNode = null,
        infoNode = null,
        documentTitle,
        bodyClassName,
        kcContext,
        i18n,
        doUseDefaultCss,
        classes,
        children
    } = props;

    const { kcClsx } = getKcClsx({ doUseDefaultCss, classes });

    const { msg, msgStr, currentLanguage, enabledLanguages } = i18n;

    const { auth, url, message, isAppInitiatedAction, properties } = kcContext;

    const homeUrl = properties.THUTO_HOME_URL;
    const realmTitle = REALM_TITLE;

    useEffect(() => {
        document.title = documentTitle ?? msgStr("loginTitle", realmTitle);
    }, []);

    useSetClassName({ qualifiedName: "html", className: "th-html" });
    useSetClassName({ qualifiedName: "body", className: bodyClassName ?? "th-body" });

    const { isReadyToRender } = useInitialize({ kcContext, doUseDefaultCss });

    if (!isReadyToRender) {
        return null;
    }

    const showAttemptedUsername = auth !== undefined && auth.showUsername && !auth.showResetCredentials;

    return (
        <div className="th-page">
            <header className="th-topbar">
                <div className="th-topbar-inner">
                    <a className="th-brand" href={homeUrl}>
                        {realmTitle}
                    </a>

                    <div className="th-topbar-actions">
                        {enabledLanguages.length > 1 && (
                            <details className="th-locale" id="kc-locale">
                                <summary aria-label={msgStr("languages")}>{currentLanguage.label}</summary>
                                <ul role="menu">
                                    {enabledLanguages.map(({ languageTag, label, href }) => (
                                        <li key={languageTag} role="none">
                                            <a role="menuitem" href={href}>
                                                {label}
                                            </a>
                                        </li>
                                    ))}
                                </ul>
                            </details>
                        )}
                        <a className="th-btn th-btn--pill" href={homeUrl}>
                            {msg("thutoBackHome")}
                        </a>
                    </div>
                </div>
            </header>

            <main className="th-main">
                <div className="th-intro">
                    <p className="th-eyebrow">{msg("thutoEyebrow")}</p>
                    <p className="th-tagline">
                        {msg("thutoTagline")} <span className="th-tagline-accent">{realmTitle}</span>
                    </p>
                </div>

                <section className="th-card">
                    <header className="th-card-head">
                        {showAttemptedUsername ? (
                            <div id="kc-username" className="th-username">
                                <span id="kc-attempted-username">{auth.attemptedUsername}</span>
                                <a id="reset-login" href={url.loginRestartFlowUrl} aria-label={msgStr("restartLoginTooltip")}>
                                    {msg("restartLoginTooltip")}
                                </a>
                            </div>
                        ) : (
                            <h1 id="kc-page-title">{headerNode}</h1>
                        )}
                        {displayRequiredFields && (
                            <p className="th-required-note">
                                <span className="th-required">*</span> {msg("requiredFields")}
                            </p>
                        )}
                    </header>

                    <div id="kc-content">
                        {/* App-initiated actions should not see warning messages about the need to complete the action during login. */}
                        {displayMessage && message !== undefined && (message.type !== "warning" || !isAppInitiatedAction) && (
                            <div className={clsx("th-alert", `th-alert--${message.type}`)} role="alert">
                                <span
                                    className="th-alert-text"
                                    dangerouslySetInnerHTML={{ __html: kcSanitize(message.summary) }}
                                />
                            </div>
                        )}

                        {children}

                        {auth !== undefined && auth.showTryAnotherWayLink && (
                            <form id="kc-select-try-another-way-form" action={url.loginAction} method="post">
                                <div className={kcClsx("kcFormGroupClass")}>
                                    <input type="hidden" name="tryAnotherWay" value="on" />
                                    <a
                                        href="#"
                                        id="try-another-way"
                                        className="th-link"
                                        onClick={event => {
                                            document.forms["kc-select-try-another-way-form" as never].requestSubmit();
                                            event.preventDefault();
                                            return false;
                                        }}
                                    >
                                        {msg("doTryAnotherWay")}
                                    </a>
                                </div>
                            </form>
                        )}

                        {socialProvidersNode}

                        {displayInfo && (
                            <div id="kc-info" className="th-info">
                                <div id="kc-info-wrapper">{infoNode}</div>
                            </div>
                        )}
                    </div>
                </section>
            </main>

            <footer className="th-footer">
                <p>
                    © {new Date().getFullYear()} {realmTitle} · {msg("thutoFooter")}
                </p>
            </footer>
        </div>
    );
}
