import { i18nBuilder } from "keycloakify/login";
import type { ThemeName } from "../kc.gen";

const { useI18n, ofTypeI18n } = i18nBuilder
    .withThemeName<ThemeName>()
    .withCustomTranslations({
        en: {
            loginAccountTitle: "Sign in to your account",
            thutoEyebrow: "Secure sign-in",
            thutoBackHome: "Back to home",
            thutoTagline: "Welcome back to",
            thutoFooter: "Protected sign-in for Thuto Education."
        }
    })
    .build();

type I18n = typeof ofTypeI18n;

export { useI18n, type I18n };
