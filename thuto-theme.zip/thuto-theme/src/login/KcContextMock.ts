import { createGetKcContextMock } from "keycloakify/login/KcContext";
import { kcEnvDefaults, themeNames } from "../kc.gen";
import type { KcContextExtension, KcContextExtensionPerPage } from "./KcContext";

/**
 * Sample page data for previewing the theme with `npm run dev`, without a running Keycloak.
 * Only loaded in development (see main.tsx); it is not part of the built theme.
 */
export const { getKcContextMock } = createGetKcContextMock({
    kcContextExtension: {
        themeName: themeNames[0],
        properties: { ...kcEnvDefaults }
    } satisfies KcContextExtension,
    kcContextExtensionPerPage: {} satisfies KcContextExtensionPerPage,
    overrides: {},
    overridesPerPage: {}
});
