import { Suspense, lazy } from "react";
import type { ClassKey } from "keycloakify/login";
import DefaultPage from "keycloakify/login/DefaultPage";
import type { KcContext } from "./KcContext";
import { useI18n } from "./i18n";
import Template from "./Template";
import "./main.css";

const UserProfileFormFields = lazy(() => import("keycloakify/login/UserProfileFormFields"));

const doMakeUserConfirmPassword = true;

export default function KcPage(props: { kcContext: KcContext }) {
    const { kcContext } = props;

    const { i18n } = useI18n({ kcContext });

    return (
        <Suspense>
            <DefaultPage
                kcContext={kcContext}
                i18n={i18n}
                classes={classes}
                Template={Template}
                // PatternFly is switched off: every page is styled by main.css through the classes below.
                doUseDefaultCss={false}
                UserProfileFormFields={UserProfileFormFields}
                doMakeUserConfirmPassword={doMakeUserConfirmPassword}
            />
        </Suspense>
    );
}

/** Maps Keycloakify's class keys onto main.css, so the stock pages pick up the Thuto Education styling. */
const classes = {
    kcFormClass: "th-form",
    kcFormGroupClass: "th-field",
    kcFormGroupErrorClass: "th-field--error",
    kcLabelWrapperClass: "th-label-wrap",
    kcLabelClass: "th-label",
    kcInputWrapperClass: "th-input-wrap",
    kcInputClass: "th-input",
    kcTextareaClass: "th-input th-textarea",
    kcInputGroup: "th-input-group",
    kcInputErrorMessageClass: "th-error-text",
    kcInputHelperTextBeforeClass: "th-helper",
    kcInputHelperTextAfterClass: "th-helper",
    kcFormPasswordVisibilityButtonClass: "th-reveal",
    kcFormPasswordVisibilityIconShow: "th-icon th-icon--eye",
    kcFormPasswordVisibilityIconHide: "th-icon th-icon--eye-off",
    kcFormSettingClass: "th-settings",
    kcFormOptionsClass: "th-options",
    kcFormOptionsWrapperClass: "th-options-wrap",
    kcFormButtonsClass: "th-buttons",
    kcFormButtonsWrapperClass: "th-buttons-wrap",
    kcButtonClass: "th-btn",
    kcButtonPrimaryClass: "th-btn--primary",
    kcButtonDefaultClass: "th-btn--secondary",
    kcButtonSecondaryClass: "th-btn--secondary",
    kcButtonBlockClass: "th-btn--block",
    kcButtonLargeClass: "th-btn--large",
    kcCheckboxInputClass: "th-checkbox",
    kcInputClassCheckbox: "th-check",
    kcInputClassCheckboxInput: "th-checkbox",
    kcInputClassCheckboxLabel: "th-check-label",
    kcInputClassRadio: "th-check",
    kcInputClassRadioInput: "th-checkbox",
    kcInputClassRadioLabel: "th-check-label",
    kcFormSocialAccountSectionClass: "th-social",
    kcFormSocialAccountListClass: "th-social-list",
    kcFormSocialAccountListGridClass: "th-social-list--grid",
    kcFormSocialAccountListButtonClass: "th-btn th-btn--secondary th-btn--block",
    kcFormSocialAccountGridItem: "th-social-item",
    kcFormSocialAccountNameClass: "th-social-name",
    kcSelectAuthListClass: "th-choice-list",
    kcSelectAuthListItemClass: "th-choice",
    kcSelectAuthListItemIconClass: "th-choice-icon",
    kcSelectAuthListItemBodyClass: "th-choice-body",
    kcSelectAuthListItemHeadingClass: "th-choice-title",
    kcSelectAuthListItemDescriptionClass: "th-choice-desc",
    kcSelectAuthListItemFillClass: "th-choice-fill",
    kcSelectAuthListItemArrowClass: "th-choice-arrow",
    kcSelectAuthListItemArrowIconClass: "th-icon th-icon--chevron",
    kcLoginOTPListClass: "th-choice-list",
    kcLoginOTPListItemHeaderClass: "th-choice",
    kcLoginOTPListItemTitleClass: "th-choice-title",
    kcRecoveryCodesList: "th-codes",
    kcRecoveryCodesWarning: "th-alert th-alert--warning",
    kcSrOnlyClass: "th-sr-only"
} satisfies { [key in ClassKey]?: string };
