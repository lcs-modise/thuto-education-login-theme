import { createRoot } from "react-dom/client";
import { StrictMode } from "react";
import { KcPage } from "./kc.gen";

function render() {
    createRoot(document.getElementById("root")!).render(
        <StrictMode>
            {!window.kcContext ? <h1>No Keycloak Context</h1> : <KcPage kcContext={window.kcContext} />}
        </StrictMode>
    );
}

if (import.meta.env.DEV && !window.kcContext) {
    // `npm run dev` only: preview the sign-in page with sample data instead of a running Keycloak.
    // The import is dropped from the production build, so it adds nothing to the theme.
    void import("./login/KcContextMock").then(({ getKcContextMock }) => {
        window.kcContext = getKcContextMock({ pageId: "login.ftl", overrides: {} });
        render();
    });
} else {
    render();
}
